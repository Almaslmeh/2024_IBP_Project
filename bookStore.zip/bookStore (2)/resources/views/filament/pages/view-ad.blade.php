<x-filament-panels::page>

    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <meta charset="utf-8">
        <meta name="application-name" content="{{ config('app.name') }}">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ config('app.name') }}</title>
        @filamentStyles
        @vite('resources/css/app.css')

        <style>
            .gradient-overlay::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: linear-gradient(to bottom, green, transparent);
                z-index: 1;
            }

            .zoom-animation {
                animation: zoomInOut 60s infinite;
                transform-origin: center center;
            }

            @keyframes zoomInOut {
                0% {
                    transform: scale(1);
                }

                50% {
                    transform: scale(1.2);
                }

                100% {
                    transform: scale(1);
                }
            }
        </style>
    </head>

    <!-- Ads Modal -->
    <div
        class="z-50 group absolute w-[70%] h-[75%] rounded-xl bg-gradient-to-r from-green-500 to-yellow-600-500 overflow-hidden -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2 {{ $showModal ? '' : 'hidden' }}">
        <div class="absolute  z-20 w-full h-full duration-700 -translate-x-1/2 -translate-y-1/2 cursor-pointer rounded-xl group-hover:scale-110 top-1/2 left-1/2"
            style="background-image: url('{{ Storage::url($firstAdImage) }}'); background-size: cover; background-position: center;">
        </div>

        <div class="flex justify-end p-4">
            <x-filament::button wire:click="hideModal" class="z-50">
                X
            </x-filament::button>
        </div>

        <div class="relative z-50 flex flex-col items-center justify-center h-full">
            <!-- Previous Button -->
            <button wire:click="previousAd"
                class="absolute z-30 p-4 text-2xl text-white transform -translate-y-1/2 left-4 top-1/3 hover:cursor-pointer">
                <i class="p-1.5 rounded-full  bg-green-500  fa fa-arrow-left"></i>
            </button>

            <!-- Ad Content -->
            <div class="z-50  flex flex-col items-center  justify-center flex-1 ">
                @if ($firstAdLink)
                    <a href="{{ $firstAdLink }}" target="_blank" class="absolute mb-4 bottom-1/4">
                        <x-filament::button>
                            Open Link
                        </x-filament::button>
                    </a>
                @else
                    <p class="text-white">No ad available.</p>
                @endif
            </div>
            <div
                class="z-50 absolute  p-4 text-2xl  text-white top-1/2 -translate-y-1/4  bg-green-300 rounded-xl font-bold">
                {{ $firstAdtitle }}</div>

            <!-- Next Button -->
            <button wire:click="nextAd"
                class="absolute right-0 z-[999] p-4 text-2xl  text-white top-1/3 -translate-y-1/2 hover:cursor-pointer">
                <i class="p-1.5 rounded-full  bg-green-500 fa fa-arrow-right"></i>
            </button>
        </div>

    </div>

    <!-- Centered Label -->
    <div class="fixed inset-0 flex items-center justify-center">
        <div class="flex flex-col items-center">
            <p class="text-3xl font-bold">Every Page Brings a New Adventure</p>
            <x-filament::button wire:click="showModalFunction" class="mt-4 cursor-pointer">
                Show Ads
            </x-filament::button>
        </div>
    </div>
</x-filament-panels::page>
