{{-- <h3 id="slogan">Where Every Page Brings a New Adventure</h3>
<style>
    @vite('resources/css/login.css')
</style> --}}
<!DOCTYPE html>
<html>

<head>
    <!-- Vite CSS -->
    @vite('resources/css/login.css')
</head>

<body>
    <h3 id="slogan">Where Every Page Brings a New Adventure</h3>

    <!-- Your other content -->

    <!-- Vite JS -->
    @vite('resources/js/app.js')
</body>

</html>
