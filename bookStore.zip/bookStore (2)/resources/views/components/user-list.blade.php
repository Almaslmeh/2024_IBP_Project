<div
    class="w-full flex md:block md:h-[35rem] bg-gray-800 rounded-3xl text-white text-lg px-2 md:p-5 font-semibold @if (count($allUsers) === 0) md:hidden @endif">
    <div class="hidden md:block">All Users</div>
    <div class="flex overflow-y-scroll md:block">
        @foreach ($allUsers as $chatUser)
            <div wire:click="selectUser({{ $chatUser->id }})"
                class="mx-2 md:mx-0 p-1 md:p-5 my-2 text-lg font-normal bg-gray-400 cursor-pointer rounded-xl hover:bg-gray-600
                 {{ $chatUser->id === $receiver_id ? 'border-4 border-green-500' : '' }}">
                <div class="flex items-center">
                    <img class="w-10 h-10 rounded-full"
                        src="https://avatar-management--avatars.us-west-2.prod.public.atl-paas.net/default-avatar.png" />
                    <div class="flex items-center justify-between w-full">
                        <div class="mx-5">
                            {{ $chatUser->name }}
                            <div class="text-sm text-green-400">{{ $chatUser->email }}</div>
                        </div>
                        @if ($this->hasUnreadMessages($chatUser->id))
                            <div class="unread-dot"></div>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
