
<!DOCTYPE html>
<html>

<head>
    <!-- Vite CSS -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/login.css'); ?>
</head>

<body>
    <h3 id="slogan">Where Every Page Brings a New Adventure</h3>

    <!-- Your other content -->

    <!-- Vite JS -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html>
<?php /**PATH F:\laravel_project\adel\bookStore\backup\resources\views/filament/login_extra.blade.php ENDPATH**/ ?>