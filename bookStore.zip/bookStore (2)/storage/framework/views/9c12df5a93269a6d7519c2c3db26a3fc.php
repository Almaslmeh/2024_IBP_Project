<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <meta charset="utf-8">
        <meta name="application-name" content="<?php echo e(config('app.name')); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name')); ?></title>

        <style>
            [x-cloak] {
                display: none !important;
            }

            .unread-dot {
                width: 15px;
                height: 15px;
                background-color: rgb(72, 244, 72);
                border-radius: 50%;
                display: inline-block;
                margin-left: 5px;
            }
        </style>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const messageList = document.getElementById('message-list');
                if (messageList) {
                    messageList.scrollTop = messageList.scrollHeight;
                }

                Livewire.hook('message.processed', (message, component) => {
                    const messageList = document.getElementById('message-list');
                    if (messageList) {
                        messageList.scrollTop = messageList.scrollHeight;
                    }
                });
            });
        </script>

        <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    </head>

    
    <div class="relative h-screen md:h-[35rem] ">
        <!-- Users Section -->

        <div class="w-full h-20   font-semibold <?php if(count($allUsers) === 0): ?> md:hidden <?php endif; ?>">
            <div class="flex mb-5 -translate-y-3 bg-gray-800 rounded-md">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div wire:click="selectUser(<?php echo e($chatUser->id); ?>)"
                        class="relative flex flex-col justify-center m-2 text-center group">
                        <div
                            class="flex items-center justify-center p-2 mx-auto text-white rounded-full cursor-pointer <?php echo e($this->hasUnreadMessages($chatUser->id) ? 'outline outline-2 outline-offset-2 outline-green-500' : ''); ?>   <?php echo e($chatUser->id === $receiver_id ? 'bg-green-800 hover:bg-green-900' : 'bg-slate-900 hover:bg-zinc-900'); ?> w-14 h-14 ">
                            <i class=" fa-lg fa fa-user"></i>
                        </div>
                        <div class=""><?php echo e($chatUser->name); ?></div>

                        <div
                            class="absolute top-0 pb-5 text-green-800 duration-300 -translate-x-1/2 -translate-y-full opacity-0 group-hover:opacity-100 left-1/2">
                            <div class="px-3 py-1 text-sm font-bold bg-green-200 rounded-lg"><?php echo e($chatUser->email); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>


        <!-- Messages Section -->
        <div
            class="w-full md:h-[25rem]  overflow-y-scroll col-span-2 <?php if(count($allUsers) === 0): ?> col-span-3 <?php endif; ?>">
            <!-- Message List -->
            <div id="message-list" class="flex-1 mb-20 space-y-2 overflow-y-auto md:p-4 md:mb-14">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div
                        class="flex md:w-full w-[75%] <?php if($message->sender_id === Auth::id()): ?> justify-end <?php else: ?> justify-start <?php endif; ?>">
                        <div
                            class="p-4 rounded-2xl max-w-xs <?php if($message->sender_id === Auth::id()): ?> bg-green-200 <?php else: ?> bg-green-500 <?php endif; ?>">
                            <div
                                class="font-bold underline <?php if($message->sender_id === Auth::id()): ?> text-green-500 <?php else: ?> text-white <?php endif; ?>">
                                <!--[if BLOCK]><![endif]--><?php if($message->sender_id === Auth::id()): ?>
                                    Me
                                <?php else: ?>
                                    <?php echo e(optional($message->sender)->name ?? 'Unknown Sender'); ?>

                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="<?php if($message->sender_id === Auth::id()): ?> text-green-500 <?php else: ?> text-white <?php endif; ?>">
                                <?php echo e($message->message); ?>

                            </div>
                            <div
                                class="text-xs border-t mt-2 <?php if($message->sender_id === Auth::id()): ?> text-green-500 <?php else: ?> text-white <?php endif; ?>">
                                <!--[if BLOCK]><![endif]--><?php if($message->isRead): ?>
                                    <i class="fa fa-check done-icon"></i>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php echo e($message->created_at->diffForHumans()); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <!-- Input Form -->

        </div>
        <div class="absolute bottom-0 right-0 flex items-center w-[100%] md:w-[100%] p-4 bg-gray-800 rounded-xl">
            <input type="text" wire:model="sendingMessage" placeholder="Type your message here..."
                class="flex-1 p-2 text-green-500 bg-gray-200 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
            <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['wire:click' => 'sendMessage','type' => 'submit','class' => 'mx-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'sendMessage','type' => 'submit','class' => 'mx-2']); ?>
                Send
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>



<!-- Users Section -->


<?php /**PATH F:\laravel_project\adel\bookStore\backup\resources\views/filament/pages/chats.blade.php ENDPATH**/ ?>