<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <head>
        <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    </head>

    <style>

    </style>

    

    <div class="grid grid-cols-1 gap-6 p-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="relative w-full max-w-sm overflow-hidden bg-white border border-gray-200 rounded-lg shadow group dark:bg-gray-800 dark:border-gray-700">

                <div
                    class="absolute px-1 text-sm text-green-800 py-0.5 bg-green-300 rounded-md font-semibold top-2 left-2">
                    <?php echo e($book->pages); ?> Pages
                </div>

                <div class="flex justify-center w-full">
                    <a href="#">
                        <img class="items-center h-64 p-3 rounded-t-lg" src="<?php echo e(Storage::url($book->image)); ?>"
                            alt="product image" />
                    </a>
                </div>

                <div class="px-5 pb-5">
                    <a href="#">
                        <h5 class="text-lg font-semibold tracking-tight text-gray-900 dark:text-white">
                            <?php echo e($book->name); ?>

                        </h5>
                    </a>

                    <div class="flex items-center mb-5">
                        Author:
                        <span
                            class="bg-green-100 text-green-800 text-xs font-semibold px-2 py-0.5 rounded dark:bg-green-200 dark:text-green-800 mx-1">
                            <?php echo e($book->author); ?>

                        </span>
                    </div>

                    <div class="flex items-center justify-between">
                        <span class="text-xl font-bold text-gray-900 dark:text-white">
                            $<?php echo e($book->price); ?>

                        </span>

                    </div>
                </div>

                <div
                    class="absolute bottom-0 left-0 w-full p-5 text-black transition-all duration-500 ease-in-out translate-y-full bg-green-400 backdrop-blur rounded-tr-xl rounded-tl-xl group-hover:translate-y-0 ">

                    <div
                        class="w-full text-white mb-5 bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-3 py-1.5 text-center cursor-pointer dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">
                        Add to cart
                    </div>

                    <p><strong class="text-green-800">Release Date:</strong>
                        <?php echo e(date('Y-m-d', strtotime($book->release_date))); ?></p>
                    <p><strong class="text-green-800">Publisher:</strong> <?php echo e($book->publisher); ?></p>
                    <p><strong class="text-green-800">Stock Quantity:</strong> <?php echo e($book->stock_quantity); ?></p>
                    <p><strong class="text-green-800">Language:</strong> <?php echo e($book->language); ?></p>
                    <p><strong class="text-green-800">Description:</strong> <?php echo e($book->description); ?></p>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>




<?php /**PATH F:\laravel_project\adel\bookStore\backup\resources\views/filament/pages/view-book.blade.php ENDPATH**/ ?>