<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'author',
        'price',
        'image',
        'release_date',
        'publisher',
        'description',
        'stock_quantity',
        'pages',
        'language',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'release_date' => 'date',
        'stock_quantity' => 'integer',
        'pages' => 'integer',
    ];
}
