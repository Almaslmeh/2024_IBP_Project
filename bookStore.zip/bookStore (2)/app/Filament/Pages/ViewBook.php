<?php

namespace App\Filament\Pages;

use App\Models\Book;
use Filament\Pages\Page;
use Illuminate\Database\Eloquent\Collection;


class ViewBook extends Page
{

    protected static ?string $model = Book::class;

    public Collection $books;

    protected static ?string $navigationIcon = 'heroicon-o-document-text';

    protected static string $view = 'filament.pages.view-book';


    public function mount()
    {

        // Fetch all ads
        $this->books = Book::all();
    }
}
