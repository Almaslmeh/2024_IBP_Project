<?php

namespace App\Filament\Pages;

use App\Models\Ad;
use Filament\Pages\Page;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Session;

class ViewAd extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-document-text';

    protected static string $view = 'filament.pages.view-ad';


    protected static ?int $navigationSort = -1;
    protected static ?string $model = Ad::class;

    public $showModal = true;
    public Collection $ads;
    public $currentAdIndex = 0;
    public $firstAdImage;
    public $firstAdLink;
    public $firstAdtitle;
    public $firstAdDesc;

    public function mount()
    {
        Session::put('showModal', true);
        $this->showModal = Session::get('showModal', true);

        // Fetch all ads
        $this->ads = Ad::all();

        // Ensure there's at least one ad
        if ($this->ads->isNotEmpty()) {
            $this->setAdProperties(0);
        }
    }

    public function showModalFunction()
    {
        // dd('fdsfsfs');
        $this->showModal = true;
        Session::put('showModal', true);
    }

    public function hideModal()
    {

        $this->showModal = false;
        Session::put('showModal', false);
    }

    public function previousAd()
    {
        $this->currentAdIndex = ($this->currentAdIndex - 1 + $this->ads->count()) % $this->ads->count();
        $this->setAdProperties($this->currentAdIndex);
    }

    public function nextAd()
    {
        $this->currentAdIndex = ($this->currentAdIndex + 1) % $this->ads->count();
        $this->setAdProperties($this->currentAdIndex);
    }

    private function setAdProperties($index)
    {
        $ad = $this->ads[$index];
        $this->firstAdImage = $ad->image_path;
        $this->firstAdLink = $ad->link;
        $this->firstAdtitle = $ad->title;
        // $this->firstAdDesc = $ad->link;
    }
}
