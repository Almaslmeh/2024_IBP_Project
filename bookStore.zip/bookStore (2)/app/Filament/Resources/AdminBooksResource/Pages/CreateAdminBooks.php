<?php

namespace App\Filament\Resources\AdminBooksResource\Pages;

use App\Filament\Resources\AdminBooksResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAdminBooks extends CreateRecord
{
    protected static string $resource = AdminBooksResource::class;
}
