<?php

namespace App\Filament\Resources\AdminBooksResource\Pages;

use App\Filament\Resources\AdminBooksResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListAdminBooks extends ListRecords
{
    protected static string $resource = AdminBooksResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
