<?php

namespace App\Filament\Resources\AdminBooksResource\Pages;

use App\Filament\Resources\AdminBooksResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditAdminBooks extends EditRecord
{
    protected static string $resource = AdminBooksResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
