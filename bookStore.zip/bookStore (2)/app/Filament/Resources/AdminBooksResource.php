<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AdminBooksResource\Pages;
use App\Models\Book;
use Filament\Actions\DeleteAction;
use Filament\Actions\EditAction;
use Filament\Actions\ViewAction;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TagsInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\DeleteBulkAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class AdminBooksResource extends Resource
{
    protected static ?string $model = Book::class;

    protected static ?string $pluralModelLabel = 'Manage Books'; // Change this to the desired sidebar label


    protected static ?string $navigationIcon = 'heroicon-o-book-open';
    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make()->schema([
                    Section::make('Basic Information')
                        ->description('The basic information of the book')
                        ->schema([
                            TextInput::make('name')
                                ->label('Book Name')
                                ->required()
                                ->maxLength(255),
                            TextInput::make('author')
                                ->label('Author')
                                ->required()
                                ->maxLength(255),

                        ])->columns(2),

                    Section::make('Details')
                        ->description('Additional details about the book')->description('The basic information of the book')
                        ->schema([

                            DatePicker::make('release_date')
                                ->label('Release Date')
                                ->minDate(now()->subYears(150))
                                ->maxDate(now())
                                ->required(),
                            TextInput::make('publisher')
                                ->label('Publisher')
                                ->maxLength(255),  Textarea::make('description')
                                ->label('Description')->columnSpan(2),


                        ])->columns(2),

                ])->columnSpan(1)
                    ->columns(2),
                Section::make('Additional Information')
                    ->description('Additional information of the book')
                    ->schema([
                        FileUpload::make('image')
                            ->label('Cover Image')
                            ->disk('public')
                            ->directory('images')
                            ->image()
                            ->required()->columnSpan(2),
                        TextInput::make('price')
                            ->label('Price')
                            ->required()
                            ->numeric(),
                        TextInput::make('stock_quantity')
                            ->label('Stock Quantity')
                            ->required()
                            ->numeric(),
                        TextInput::make('pages')
                            ->label('Pages')
                            ->numeric(),
                        TagsInput::make('language')
                            ->label('Language')
                            ->separator(',')
                            ->suggestions([
                                'arabic',
                                'english',
                                'عربي',
                                'انكليزي',
                                'spanish',
                                'french'
                            ]),


                    ])->columnSpan(1)
                    ->columns(2),


            ])
            ->columns(2);
    }


    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->sortable()->searchable(),
                TextColumn::make('author')->sortable()->searchable(),
                TextColumn::make('price')->sortable(),
                ImageColumn::make('image'),
                TextColumn::make('stock_quantity')->sortable(),
                TextColumn::make('language')->sortable()->searchable()->badge()->color(function (bool $state) {
                    return match ($state) {
                        'arabic' => 'success',
                        'english' => 'info',
                        default => 'primary', // default color if no match
                    };
                }),
                TextColumn::make('created_at')->date(),
                // TextColumn::make('pages')->sortable(),
                // TextColumn::make('release_date')->sortable(),
                // TextColumn::make('publisher')->sortable()->searchable(),
                // TextColumn::make('description')->limit(50),
                // TextColumn::make('updated_at')->dateTime(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\ViewAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAdminBooks::route('/'),
            'create' => Pages\CreateAdminBooks::route('/create'),
            'edit' => Pages\EditAdminBooks::route('/{record}/edit'),
        ];
    }

    public static function getNavigationBadge(): ?string
    {
        // Return the count of books as a string
        return (string) Book::count();
    }

    public static function canViewAny(): bool
    {
        return Auth()->user()->role;
    }
}
