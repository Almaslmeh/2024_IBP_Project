<?php

namespace App\Filament\Resources;

use App\Filament\Resources\UserResource\Pages;
use App\Filament\Resources\UserResource\RelationManagers;
use App\Models\User;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\BooleanColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Phpsa\FilamentPasswordReveal\Password;

class UserResource extends Resource
{
    protected static ?string $model = User::class;

    protected static ?string $navigationIcon = 'heroicon-o-users';

    protected static ?string $pluralModelLabel = 'Manage Users'; // Change this to the desired sidebar label


    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')->required(),
                TextInput::make('email')->email()->required()->unique(ignoreRecord: true),
                DatePicker::make('email_verified_at'),
                // TextInput::make('password')->password()->required()->minLength(8),
                Password::make('password')->password()->required()->minLength(8)->initiallyHidden(),
                Toggle::make('role')->label('Admin Role')->default(false),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                // TextColumn::make('id')->sortable(),
                TextColumn::make('name')->sortable()->searchable(),
                TextColumn::make('email')->sortable()->searchable(),
                TextColumn::make('role')
                    ->formatStateUsing(fn (string $state): string => __($state == 1 ? 'Admin' : 'Customer'))
                    ->badge()
                    ->color(function (bool $state) {
                        return match ($state) {
                            true => 'success',
                            false => 'info',
                        };
                    }),
                TextColumn::make('created_at')->dateTime()->sortable(),

            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\ViewAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListUsers::route('/'),
            'create' => Pages\CreateUser::route('/create'),
            'edit' => Pages\EditUser::route('/{record}/edit'),
            // 'view' => ViewUser::route('/{record}'),
        ];
    }


    public static function getNavigationBadge(): ?string
    {
        return (string) User::count();
    }

    public static function canViewAny(): bool
    {
        return Auth()->user()->role;
    }
}



   // TextColumn::make('updated_at')->dateTime()->sortable(),
                // DateColumn::make('email_verified_at')->sortable(),
                // DateColumn::make('created_at')->sortable(),
                // DateColumn::make('updated_at')->sortable(),
