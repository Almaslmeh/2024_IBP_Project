<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AdResource\Pages;
use App\Filament\Resources\AdResource\RelationManagers;
use App\Models\Ad;
use Filament\Forms;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class AdResource extends Resource
{
    protected static ?string $model = Ad::class;


    protected static ?string $pluralModelLabel = 'Manage Advertisement'; // Change this to the desired sidebar label
    protected static ?string $navigationIcon = 'heroicon-s-newspaper';


    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make()->schema([

                    TextInput::make('title')
                        ->required()
                        ->maxLength(255),
                    TextInput::make('link')
                        ->required()
                        ->url(),
                    Textarea::make('description')
                        ->required()->columnSpan(2),
                ])->columnSpan(1)->columns(2),

                Section::make()->schema([
                    FileUpload::make('image_path')
                        ->label('Image')
                        ->directory('ads')
                        ->visibility('public') // Ensure visibility is set to public
                        ->image()
                        ->required(),
                ])->columnSpan(1)
            ])->columns(2);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('title')->sortable()->searchable(),
                // TextColumn::make('description')->sortable()->searchable()->truncate(50),
                TextColumn::make('link')->sortable()->searchable(),
                ImageColumn::make('image_path')->label('Image'),
                TextColumn::make('created_at')->date(),
                TextColumn::make('updated_at')->date(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\CreateAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAds::route('/'),
            'create' => Pages\CreateAd::route('/create'),
            'edit' => Pages\EditAd::route('/{record}/edit'),
        ];
    }

    public static function getNavigationBadge(): ?string
    {
        return (string) Ad::count();
    }


    public static function getNavigationBadgeColor(): string|array|null
    {
        return (string) 'info';
    }

    public static function canViewAny(): bool
    {
        return Auth()->user()->role;
    }
}
