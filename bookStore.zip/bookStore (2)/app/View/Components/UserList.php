<?php

namespace App\View\Components;

use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

class UserList extends Component
{
    /**
     * Create a new component instance.
     */

    public $allUsers;
    public $receiver_id;

    public function __construct($allUsers, $receiver_id)
    {

        $this->allUsers = $allUsers;
        $this->receiver_id = $receiver_id;
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        dd($this->allUsers);
        return view('components.user-list');
    }
}
